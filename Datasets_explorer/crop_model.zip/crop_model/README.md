# READ ME

WOFOST output of crop yield in kg.ha-1 in Brandenburg.

Crop types:
- Maize (maize)
- Winter Wheat (wwh)
- Winter Rye (wrye)
- Spring Barley (barley)

Model types:
- Water limited production (wlp)
- Potential production (pp)

Formats:
- NetCDF
- TIFF